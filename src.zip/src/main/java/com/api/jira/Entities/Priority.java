package com.api.jira.Entities;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH;
}