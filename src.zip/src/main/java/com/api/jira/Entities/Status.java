package com.api.jira.Entities;

public enum Status {
    TODO,
    EN_COURS,
    TERMINE
}